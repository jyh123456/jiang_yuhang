#include<string>
class Account
{
public:
    explicit Account(std::int);
    credit(std::int);
    debit(std::int);
    void getBalance();
private:
    int rest;
};
