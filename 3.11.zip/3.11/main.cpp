#include <iostream>
#include "GradeBook.h"
using namespace std;
int main()
{
    GradeBook gradebook("C++","Mr Shi");

    gradebook.displayMessage();
    return 0;
}
