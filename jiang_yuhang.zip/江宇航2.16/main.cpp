#include <iostream>

using namespace std;

int main()
{
    double number1,number2;
    cout<<"Enter two numbers";
    cin>>number1>>number2;
    cout<<"�ͣ�"<<number1+number2<<endl;
    cout<<"�"<<number1-number2<<endl;
    cout<<"����"<<number1*number2<<endl;
    cout<<"�̣�"<<number1/number2<<endl;
    return 0;
}
