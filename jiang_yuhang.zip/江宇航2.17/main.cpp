#include <iostream>

using namespace std;

int main()
{
    cout<<"1 2 3 4 \n";
    cout<<"1 "<<"2 "<<"3 "<<"4 \n";
    cout<<"1 ";
    cout<<"2 ";
    cout<<"3 ";
    cout<<"4";
    return 0;
}
