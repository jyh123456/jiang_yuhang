#include <iostream>

using namespace std;

int main()
{
    int radius;
    cout<<"Input the radius:";
    cin>>radius;
    cout<<"D is:"<<radius*2<<endl;
    cout<<"C is:"<<2*3.14159*radius<<endl;
    cout<<"S is:"<<3.14159*radius*radius<<endl;
    return 0;
}
